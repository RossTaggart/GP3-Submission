#include "cEnemy.h"

cEnemy::cEnemy() : cModel()
{

}

void cEnemy::randomisePosition()
{
	int lanePos = rand() % 3 + 1;
	switch (lanePos)
	{
		case 1:
			setPosition(glm::vec3(customerStartPosX, customerStartPosY[0], 10));
			break;
		case 2:
			setPosition(glm::vec3(customerStartPosX, customerStartPosY[1], 10));
			break;
		case 3:
			setPosition(glm::vec3(customerStartPosX, customerStartPosY[2], 10));
			break;
	}

	update(0.0f);
}

void cEnemy::randomise()
{
	if (rand() % 2 == 0)
	{
		cModel::m_mdlPosition.x = -PLAYFIELDX;
	}
	else
	{
		cModel::m_mdlPosition.x = PLAYFIELDX;
	}

	cModel::m_mdlPosition.y = 0.0f;
	cModel::m_mdlPosition.z = (rand() / (float)RAND_MAX) * 300.0f; //random number as float between 0 and 1
	cModel::m_mdlRotation = (rand() / (float)RAND_MAX) * 2 * 3.14f;
	cModel::m_mdlDirection.x = -(float)glm::sin(cModel::m_mdlRotation);
	cModel::m_mdlDirection.z = (float)glm::cos(cModel::m_mdlRotation);
	cModel::m_mdlSpeed = m_EnemyMinSpeed + rand() / (float)RAND_MAX * m_EnemyMaxSpeed;
	cModel::m_IsActive = true;
}

void cEnemy::update(float elapsedTime)
{

	move();
	if (cModel::m_mdlPosition.x > 10.5 || cModel::m_mdlPosition.x < -10.5)
	{
		setIsActive(false);
		gameOverLose = true;
	}
	
}

void cEnemy::setSpeed(float speed)
{
	speedOfModel = speed;
}

void cEnemy::setModelNumber(int modelNo)
{
	modelNumber = modelNo;
}

int cEnemy::getModelNumber()
{
	return modelNumber;
}

void cEnemy::move()
{
	//do movement here
	//Test loop for moving customer towards player
	float distance = sqrt(pow(19.0f - cModel::m_mdlPosition.x, 2) + pow(4.0f - cModel::m_mdlPosition.y, 2));
	float startX = cModel::m_mdlPosition.x;
	float startY = cModel::m_mdlPosition.y;
	float directionX = (19.0f - startX) / distance;
	float directionY = (4.0f - startY) / distance;
	bool moving = true;

	if (moving)
	{
		cModel::m_mdlPosition = glm::vec3(cModel::m_mdlPosition.x + (directionX * 1 * 0.02f), cModel::m_mdlPosition.y, cModel::m_mdlPosition.z);

		if (sqrt(pow(cModel::m_mdlPosition.x - startX, 2) + pow(cModel::m_mdlPosition.y - startY, 2)) >= distance)
		{
			cModel::m_mdlPosition = glm::vec3(19.0f, 4.0f, cModel::m_mdlPosition.z);
		}
	}
}

cEnemy::~cEnemy()
{

}
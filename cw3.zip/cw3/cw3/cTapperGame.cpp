#include "cTapperGame.h"

std::vector<cEnemy*> theEnemy;
std::vector<cLaser*> theGlasses;
int gameScore = 0;


